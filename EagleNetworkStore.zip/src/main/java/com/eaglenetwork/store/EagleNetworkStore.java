package com.eaglenetwork.store;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class EagleNetworkStore extends JavaPlugin implements Listener, CommandExecutor {

    private String pairingCode;
    private boolean isPaired = false;
    private final Map<UUID, String> playerPasswords = new HashMap<>();
    private final Map<UUID, Boolean> isLoggedIn = new HashMap<>();
    private final Map<UUID, Integer> playerCoins = new HashMap<>();
    private final Map<UUID, List<String>> pendingDeliveries = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);

        this.pairingCode = "ENS-" + (100000 + new Random().nextInt(900000));
        
        new BukkitRunnable() {
            @Override
            public void run() {
                if (isPaired) {
                    cancel();
                    return;
                }
                getLogger().warning("==================================================");
                getLogger().warning("[EagleNetwork] STORE NOT CONNECTED!");
                getLogger().warning("[EagleNetwork] Enter this pairing code in your Admin Panel:");
                getLogger().warning("[EagleNetwork] CODE: >>> " + pairingCode + " <<<");
                getLogger().warning("==================================================");
            }
        }.runTaskTimer(this, 0L, 100L);

        getLogger().info("EagleNetworkStore has been enabled successfully!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(color("&cOnly players can execute this command."));
            return true;
        }

        Player player = (Player) sender;
        UUID uuid = player.getUniqueId();

        if (cmd.getName().equalsIgnoreCase("register")) {
            if (args.length < 1) {
                player.sendMessage(color("&c[ENS] Usage: /register <password>"));
                return true;
            }
            if (playerPasswords.containsKey(uuid)) {
                player.sendMessage(color("&e[ENS] You are already registered! Use /login <password> instead."));
                return true;
            }
            playerPasswords.put(uuid, args[0]);
            isLoggedIn.put(uuid, true);
            player.sendMessage(color("&a[ENS] Registration successful! Your store account is ready."));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("login")) {
            if (args.length < 1) {
                player.sendMessage(color("&c[ENS] Usage: /login <password>"));
                return true;
            }
            if (!playerPasswords.containsKey(uuid)) {
                player.sendMessage(color("&c[ENS] You are not registered! Use /register <password> first."));
                return true;
            }
            if (playerPasswords.get(uuid).equals(args[0])) {
                isLoggedIn.put(uuid, true);
                player.sendMessage(color("&a[ENS] Successfully logged in!"));
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
                checkPendingDeliveries(player);
            } else {
                player.sendMessage(color("&c[ENS] Incorrect password! Try again."));
            }
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("ens")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("help")) {
                sendAnimatedHelp(player);
                return true;
            }

            if (args.length > 0 && args[0].equalsIgnoreCase("givecoins")) {
                if (!player.hasPermission("eaglenetwork.admin")) {
                    player.sendMessage(color("&c[ENS] You do not have permission to use admin commands!"));
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage(color("&c[ENS] Usage: /ens givecoins <player> <amount>"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target != null) {
                    int amount = Integer.parseInt(args[2]);
                    addCoins(target, amount);
                    player.sendMessage(color("&a[ENS] Gave " + amount + " coins to " + target.getName()));
                    target.sendMessage(color("&e[ENS] You received " + amount + " EagleCoins from Owner/Admin!"));
                } else {
                    player.sendMessage(color("&c[ENS] Player not found online."));
                }
                return true;
            }

            openMainStoreMenu(player);
            return true;
        }

        return false;
    }

    private void openMainStoreMenu(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, color("&8🦅 &lEagleNetwork Store Menu"));

        gui.setItem(11, createGuiItem(Material.DISPENSER, "&e&l🎰 Daily Spin Wheel", "&7Spin every day to win free EagleCoins!"));
        gui.setItem(13, createGuiItem(Material.NETHER_STAR, "&a&l📅 Daily Login Reward", "&7Click to collect today's free bonus!"));
        gui.setItem(15, createGuiItem(Material.WRITABLE_BOOK, "&b&l📜 Daily Quests & Tasks", "&7Complete tasks to earn extra coins."));

        player.openInventory(gui);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }

    private void runAnimatedSpin(Player player) {
        Inventory spinGui = Bukkit.createInventory(null, 27, color("&6&l🎰 Spinning Wheel..."));
        player.openInventory(spinGui);

        ItemStack[] items = {
                new ItemStack(Material.EMERALD),
                new ItemStack(Material.DIAMOND),
                new ItemStack(Material.GOLD_INGOT),
                new ItemStack(Material.IRON_INGOT)
        };

        new BukkitRunnable() {
            int ticks = 0;
            Random rand = new Random();

            @Override
            public void run() {
                if (ticks > 20) {
                    this.cancel();
                    int wonCoins = (rand.nextInt(5) + 1) * 50;
                    addCoins(player, wonCoins);
                    player.sendMessage(color("&a&l[ENS] 🎉 Spin Complete! You won &e" + wonCoins + " EagleCoins&a!"));
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                    return;
                }
                for (int i = 0; i < 27; i++) {
                    spinGui.setItem(i, items[rand.nextInt(items.length)]);
                }
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 2f);
                ticks++;
            }
        }.runTaskTimer(this, 0L, 2L);
    }

    private void sendAnimatedHelp(Player player) {
        new BukkitRunnable() {
            int step = 0;
            final String[] lines = {
                    "&6===========================================",
                    "&e&l🦅 EAGLE NETWORK STORE - HELP MENU 🦅",
                    "&7- &b/register <pass> &f: Create Store Account",
                    "&7- &b/login <pass>    &f: Log into Game/Store",
                    "&7- &b/ens             &f: Open Main Store & Coin GUI",
                    "&7- &b/ens help        &f: Display this help menu"
            };

            @Override
            public void run() {
                if (step >= lines.length) {
                    if (player.hasPermission("eaglenetwork.admin")) {
                        player.sendMessage(color("&c&lADMIN COMMANDS:"));
                        player.sendMessage(color("&7- &c/ens givecoins <player> <amount>"));
                    }
                    player.sendMessage(color("&6==========================================="));
                    this.cancel();
                    return;
                }
                player.sendMessage(color(lines[step]));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 1f, 1.2f);
                step++;
            }
        }.runTaskTimer(this, 0L, 3L);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        isLoggedIn.put(uuid, false);

        player.sendMessage(color("&e[EagleNetwork] Welcome! Please &a/register <password>&e or &a/login <password>&e to access store features."));

        if (pendingDeliveries.containsKey(uuid)) {
            checkPendingDeliveries(player);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().contains("EagleNetwork")) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        if (event.getRawSlot() == 11) {
            player.closeInventory();
            runAnimatedSpin(player);
        } else if (event.getRawSlot() == 13) {
            player.closeInventory();
            addCoins(player, 100);
            player.sendMessage(color("&a[ENS] Daily bonus claimed! Received &e100 EagleCoins&a."));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        } else if (event.getRawSlot() == 15) {
            player.sendMessage(color("&b[ENS] Daily Quests feature coming soon!"));
        }
    }

    public void deliverOfflineStoreItem(UUID uuid, String command) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline() && isLoggedIn.getOrDefault(uuid, false)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.replace("%player%", player.getName()));
            player.sendMessage(color("&a&l[ENS Store] Your store item has been delivered!"));
        } else {
            pendingDeliveries.computeIfAbsent(uuid, k -> new ArrayList<>()).add(command);
        }
    }

    private void checkPendingDeliveries(Player player) {
        UUID uuid = player.getUniqueId();
        if (pendingDeliveries.containsKey(uuid)) {
            List<String> commands = pendingDeliveries.remove(uuid);
            for (String cmd : commands) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", player.getName()));
            }
            player.sendMessage(color("&a&l[ENS Store] You had pending store items! They have now been delivered."));
        }
    }

    private void addCoins(Player player, int amount) {
        int current = playerCoins.getOrDefault(player.getUniqueId(), 0);
        playerCoins.put(player.getUniqueId(), current + amount);
    }

    private ItemStack createGuiItem(Material mat, String name, String lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            meta.setLore(Collections.singletonList(color(lore)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
